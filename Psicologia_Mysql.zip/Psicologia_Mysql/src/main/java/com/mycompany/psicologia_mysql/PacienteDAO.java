package com.mycompany.psicologia_mysql;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class PacienteDAO {

    PacienteVO paciente = new PacienteVO();

    public void InsertarPaciente(JTextField paramDocumento, JTextField paramNombre, JTextField paramUsuario, JTextField paramEdad,
            JTextField paramCorreo, JTextField paramTelefono, JTextField paramContrasena) {

        paciente.setDocumento(paramDocumento.getText());
        paciente.setNombre(paramNombre.getText());
        paciente.setNombreUsuario(paramUsuario.getText());
        paciente.setEdad(paramEdad.getText());
        paciente.setEmail(paramCorreo.getText());
        paciente.setTelefono(paramTelefono.getText());
        paciente.setContrasena(paramContrasena.getText());

        Conexion objetoConexion = new Conexion();

        String consulta = "insert into Paciente (documento, nombre, nombre_usuario, edad, email, telefono, contrasena) values (?, ?, ?, ?, ?, ?, ?);";

        try {

            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);

            cs.setString(1, paciente.getDocumento());
            cs.setString(2, paciente.getNombre());
            cs.setString(3, paciente.getNombreUsuario());
            cs.setString(4, paciente.getEdad());
            cs.setString(5, paciente.getEmail());
            cs.setString(6, paciente.getTelefono());
            cs.setString(7, paciente.getContrasena());

            cs.execute();

            JOptionPane.showMessageDialog(null, "Se ha insertado de manera correcta el paciente");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al insertar el paciente, error: " + e.toString());
        }
    }

    public void buscarPaciente(JTable paramTablaPacientes) {

        Conexion objetoConexion = new Conexion();

        DefaultTableModel modelo = new DefaultTableModel();

        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        paramTablaPacientes.setRowSorter(OrdenarTabla);

        String sql = "";

        modelo.addColumn("Id");
        modelo.addColumn("Documento");
        modelo.addColumn("Nombre");
        modelo.addColumn("Nombre Usuario");
        modelo.addColumn("Edad");
        modelo.addColumn("Correo");
        modelo.addColumn("Telefono");
        modelo.addColumn("Contraseña");

        paramTablaPacientes.setModel(modelo);

        sql = "SELECT * FROM paciente;";

        String[] datos = new String[8];
        Statement st;

        try {
            st = objetoConexion.estableceConexion().createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                datos[5] = rs.getString(6);
                datos[6] = rs.getString(7);
                datos[7] = rs.getString(8);

                modelo.addRow(datos);
            }

            paramTablaPacientes.setModel(modelo);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "Error al mostrar los datos, error: " + e.toString());
        }
    }

    public void Seleccion(JTable paramTablaPacientes, JTextField paramId, JTextField paramDocumento, JTextField paramNombre, JTextField paramUsuario, JTextField paramEdad,
            JTextField paramCorreo, JTextField paramTelefono, JTextField paramContrasena) {

        try {
            int fila = paramTablaPacientes.getSelectedRow();
            if (fila >= 0) {

                paramId.setText((String) (paramTablaPacientes.getValueAt(fila, 0)));
                paramDocumento.setText((String) paramTablaPacientes.getValueAt(fila, 1));
                paramNombre.setText((String) (paramTablaPacientes.getValueAt(fila, 2)));
                paramUsuario.setText((String) (paramTablaPacientes.getValueAt(fila, 3)));
                paramEdad.setText((String) (paramTablaPacientes.getValueAt(fila, 4)));
                paramCorreo.setText((String) (paramTablaPacientes.getValueAt(fila, 5)));
                paramTelefono.setText((String) (paramTablaPacientes.getValueAt(fila, 6)));
                paramContrasena.setText((String) (paramTablaPacientes.getValueAt(fila, 7)));

            } else {
                JOptionPane.showMessageDialog(null, "La fila no se selecciono ");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al seleccionar, error: " + e.toString());

        }
    }

    public void ModificarPaciente(JTextField paramId, JTextField paramDocumento, JTextField paramNombre, JTextField paramUsuario, JTextField paramEdad,
            JTextField paramCorreo, JTextField paramTelefono, JTextField paramContrasena) {

        paciente.setId(Integer.parseInt(paramId.getText()));
        paciente.setDocumento(paramDocumento.getText());
        paciente.setNombre(paramNombre.getText());
        paciente.setNombreUsuario(paramUsuario.getText());
        paciente.setEdad(paramEdad.getText());
        paciente.setEmail(paramCorreo.getText());
        paciente.setTelefono(paramTelefono.getText());
        paciente.setContrasena(paramContrasena.getText());

        Conexion objetoConexion = new Conexion();

        String consulta = "UPDATE Paciente SET paciente.documento =?, paciente.nombre =?, paciente.nombre_usuario =?, paciente.edad =?, paciente.email =?, paciente.telefono =?, paciente.contrasena =? WHERE paciente.id =?;";

        try {

            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);

            cs.setString(1, paciente.getDocumento());
            cs.setString(2, paciente.getNombre());
            cs.setString(3, paciente.getNombreUsuario());
            cs.setString(4, paciente.getEdad());
            cs.setString(5, paciente.getEmail());
            cs.setString(6, paciente.getTelefono());
            cs.setString(7, paciente.getContrasena());
            cs.setInt(8, paciente.getId());

            cs.execute();

            JOptionPane.showMessageDialog(null, "Modificado correctamente.");

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(null, "Error al modificar los datos, intente de nuevo, error: " + e.toString());
        }
    }

    public void EliminarPaciente(JTextField paramId) {

        paciente.setId(Integer.parseInt(paramId.getText()));

        Conexion objetoConexion = new Conexion();

        String consulta = "DELETE FROM paciente WHERE paciente.id=?;";

        try {

            CallableStatement cs = objetoConexion.estableceConexion().prepareCall(consulta);

            cs.setInt(1, paciente.getId());
            cs.execute();

            JOptionPane.showMessageDialog(null, "Eliminado correctamente");

        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null, "Error al eliminar al paciente, intente de nuevo, Error: " + e.toString());

        }
    }
}
