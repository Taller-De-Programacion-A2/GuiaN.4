CREATE DATABASE PsicologiaDB;
USE PsicologiaDB;

CREATE TABLE Paciente (
	id int NOT NULL auto_increment Primary Key,
    documento VARCHAR(15) NOT NULL,
    nombre VARCHAR(45) NOT NULL,
    nombre_usuario VARCHAR(20) NOT NULL,
    edad VARCHAR(2) NOT NULL,
    email VARCHAR(45) NOT NULL,
    telefono VARCHAR(10) NOT NULL,
    contrasena VARCHAR(30) NOT NULL
);

/*Insertar*/
insert into Paciente (documento, nombre, nombre_usuario, edad, email, telefono, contrasena) values ('1', 'Juan', 'js', '19', 
'juan@gmail.com', '2104395489', '2130kdnsifc');

/*Mostrar*/
SELECT * FROM paciente;

/*Actualizar*/
UPDATE Paciente SET paciente.documento = '1902573', paciente.nombre = 'Killua', paciente.nombre_usuario = 'Hunter', paciente.edad = '14', paciente.email = 'HkillH@gmail.com', 
paciente.telefono = '2958473610', paciente.contrasena = 'soyFuerte' WHERE paciente.id = '1';

/*Eliminar*/
DELETE FROM paciente WHERE paciente.id='1';
DROP TABLE paciente