package com.mycompany.psicologia_mysql;

import Frame.Paciente;

public class Psicologia_Mysql {

    public static void main(String[] args) {
        Paciente paciente = new Paciente();
        paciente.setVisible(true);
    }
}
